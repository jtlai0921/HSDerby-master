package com.web.mvc.repository;

import com.web.mvc.entity.Customer;
import com.web.mvc.repository.spec.CustomerDao;
import java.sql.ResultSet;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDaoImpl implements CustomerDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Customer> queryCustomer() {
        String sql = "SELECT * FROM CUSTOMER";
        RowMapper<Customer> rowMapper = (ResultSet rs, int rowNum) -> {
            Customer customer = new Customer();
            customer.setCustomerId(rs.getInt("CUSTOMER_ID"));
            customer.setDiscountCode(rs.getString("DISCOUNT_CODE"));
            customer.setZip(rs.getString("ZIP"));
            customer.setName(rs.getString("NAME"));
            customer.setAddressLine1(rs.getString("ADDRESSLINE1"));
            customer.setAddressLine2(rs.getString("ADDRESSLINE2"));
            customer.setCity(rs.getString("CITY"));
            customer.setState(rs.getString("STATE"));
            customer.setPhone(rs.getString("PHONE"));
            customer.setFax(rs.getString("FAX"));
            customer.setEmail(rs.getString("EMAIL"));
            customer.setCreditLimit(rs.getInt("CREDIT_LIMIT"));
            return customer;
        };
        List<Customer> list = jdbcTemplate.query(sql, rowMapper);
        return list;
    }

    @Override

    public Customer getCustomer(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void saveCustomer(Customer cust) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateCustomer(Customer cust) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteCustomer(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
