package com.web.mvc.controller;

import com.google.gson.Gson;
import com.web.mvc.entity.MicroMarket;
import com.web.mvc.repository.spec.MicroMarketDao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/micro_market")
public class MicroMarketController {
    
    @Autowired
    MicroMarketDao dao;
    
    @RequestMapping("/input")
    public String input(Model model) {
        MicroMarket microMarket = new MicroMarket();
        model.addAttribute("microMarket", microMarket);
        model.addAttribute("list", dao.queryMicroMarket());
        return "micro_market"; // 轉跳到 /WEB-INF/jsp/micro_market.jsp
    }
    
}
