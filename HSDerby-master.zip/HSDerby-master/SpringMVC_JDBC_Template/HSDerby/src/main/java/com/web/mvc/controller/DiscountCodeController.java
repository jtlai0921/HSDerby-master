package com.web.mvc.controller;

import com.web.mvc.entity.DiscountCode;
import com.web.mvc.repository.spec.DiscountCodeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/discount_code")
public class DiscountCodeController {
    
    @Autowired
    private DiscountCodeDao dao;
    
    @RequestMapping("/input")
    public String input(Model model) {
        DiscountCode discountCode = new DiscountCode();
        
        model.addAttribute("discountCode", discountCode);
        model.addAttribute("list", dao.queryDiscountCode());
        return "discount_code"; // 轉跳到 /WEB-INF/jsp/discount_code.jsp
    }
    
}
