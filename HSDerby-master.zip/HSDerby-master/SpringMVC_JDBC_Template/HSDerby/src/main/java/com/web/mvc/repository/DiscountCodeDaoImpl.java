package com.web.mvc.repository;

import com.web.mvc.entity.DiscountCode;
import com.web.mvc.repository.spec.DiscountCodeDao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class DiscountCodeDaoImpl implements DiscountCodeDao {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public List<DiscountCode> queryDiscountCode() {
        String sql = "SELECT * FROM DISCOUNT_CODE";
        RowMapper<DiscountCode> rowMapper = (rs, i) -> {
            DiscountCode dc = new DiscountCode();
            dc.setDiscountCode(rs.getString("DISCOUNT_CODE"));
            dc.setRate(rs.getDouble("RATE"));
            return dc;
        };
        return jdbcTemplate.query(sql, rowMapper);
    }

    @Override
    public DiscountCode getDiscountCode(String code) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void saveDiscountCode(DiscountCode dc) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateDiscountCode(DiscountCode dc) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteDiscountCode(String code) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
