package com.web.mvc.repository;

import com.web.mvc.entity.MicroMarket;
import com.web.mvc.repository.spec.MicroMarketDao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class MicroMarketDaoImpl implements MicroMarketDao {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public List<MicroMarket> queryMicroMarket() {
        String sql = "SELECT * FROM MICRO_MARKET";
        RowMapper<MicroMarket> rowMapper = (rs, i) -> {
            MicroMarket mm = new MicroMarket();
            mm.setZipCode(rs.getString("ZIP_CODE"));
            mm.setRadius(rs.getDouble("RADIUS"));
            mm.setAreaLength(rs.getDouble("AREA_LENGTH"));
            mm.setAreaWidth(rs.getDouble("AREA_WIDTH"));
            return mm;
        };
        return jdbcTemplate.query(sql, rowMapper);
    }

    @Override
    public MicroMarket getMicroMarket(String zipCode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void saveMicroMarket(MicroMarket mm) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void updateMicroMarket(MicroMarket mm) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void deleteMicroMarket(String zipCode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
