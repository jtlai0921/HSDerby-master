package com.web.mvc.controller;

import com.web.mvc.entity.Customer;
import com.web.mvc.repository.spec.CustomerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customer")
public class CustomerController {
    
    @Autowired
    private CustomerDao dao;
    
    @RequestMapping("/input")
    public String input(Model model) {
        Customer customer = new Customer();
        model.addAttribute("customer", customer);
        model.addAttribute("list", dao.queryCustomer());
        return "customer"; // 轉跳到 /WEB-INF/jsp/customer.jsp
    }
    
}
