package com.web.listener;

import com.web.mvc.repository.spec.DerbyDao;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.springframework.web.context.support.WebApplicationContextUtils;

@WebListener
public class ApplicationData implements ServletContextListener {

//    @Autowired
//    @Qualifier("derbyDao")
//    private DerbyDao dao;
    private static final Map menus = new LinkedHashMap();

    static {
        menus.put("discount_code", new String[]{"mvc/discount_code/", "優惠碼"});
        menus.put("micro_market", new String[]{"mvc/micro_market/", "市場區域"});
        menus.put("customer", new String[]{"mvc/customer/", "客戶資料"});
        menus.put("product_code", new String[]{"mvc/product_code/", "商品代號"});
        menus.put("manufacturer", new String[]{"mvc/manufacturer/", "製造商"});
        menus.put("product", new String[]{"mvc/product/", "商品資料"});
        menus.put("purchase_order", new String[]{"mvc/purchase_order/", "採購訂單"});
        
    }

    @Override
    public void contextInitialized(ServletContextEvent event) {
        WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(event.getServletContext());
        DerbyDao dao = context.getBean(DerbyDao.class);
        System.out.println("dao: " + dao);
        try {
            System.out.println("dao: " + dao.queryMenu());
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        event.getServletContext().setAttribute("menus", menus);
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {
        // NOOP.
    }

}
