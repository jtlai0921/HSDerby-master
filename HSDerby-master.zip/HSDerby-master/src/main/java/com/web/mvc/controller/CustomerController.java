package com.web.mvc.controller;

import com.web.mvc.entity.Customer;
import com.web.mvc.entity.DiscountCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.web.mvc.repository.spec.DerbyDao;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;


@Controller
@RequestMapping("/customer")
public class CustomerController extends BaseController {
    
    @Autowired
    @Qualifier("derbyDao")
    private DerbyDao dao;
    
    @GetMapping("/")
    public String query(Model model) {
        Customer po = new Customer();
        model.addAttribute("po", po);
        model.addAttribute("list", dao.queryCustomer());
        model.addAttribute("list_dc", dao.queryDiscountCode());
        model.addAttribute("list_mm", dao.queryMicroMarket());
        model.addAttribute("page", "customer");
        model.addAttribute("_method", "POST");
        return model.asMap().get("page").toString();
    }
    
    @GetMapping("/{id}")
    public String get(@PathVariable("id") Integer id, Model model) {
        model.addAttribute("po", dao.getCustomer(id));
        model.addAttribute("list", dao.queryCustomer());
        model.addAttribute("list_dc", dao.queryDiscountCode());
        model.addAttribute("list_mm", dao.queryMicroMarket());
        model.addAttribute("page", "customer");
        model.addAttribute("_method", "PUT");
        return model.asMap().get("page").toString();
    }
    
    @PostMapping("/")
    public String post(@ModelAttribute Customer customer) {
        dao.saveCustomer(customer);
        return "redirect: ./";
    }

    @PutMapping("/")
    public String put(@ModelAttribute Customer customer) {
        dao.updateCustomer(customer);
        return "redirect: ./";
    }
    
    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") Integer id) {
        dao.deleteCustomer(id);
        return "redirect: ./";
    }
}
