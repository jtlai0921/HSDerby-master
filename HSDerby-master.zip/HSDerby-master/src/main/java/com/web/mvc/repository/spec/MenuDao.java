package com.web.mvc.repository.spec;

import com.web.mvc.entity.Menu;
import java.util.List;

public interface MenuDao {
    List<Menu> queryMenu();
}
