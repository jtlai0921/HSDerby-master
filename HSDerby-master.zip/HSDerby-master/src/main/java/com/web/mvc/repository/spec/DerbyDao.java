package com.web.mvc.repository.spec;

public interface DerbyDao extends 
        CustomerDao, DiscountCodeDao, MicroMarketDao, MenuDao,
        ProductCodeDao, ManufacturerDao, ProductDao,
        PurchaseOrderDao {
  
    
}
