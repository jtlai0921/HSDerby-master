package com.web.mvc.controller;

import com.web.mvc.entity.DiscountCode;
import com.web.mvc.repository.spec.DerbyDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/discount_code")
public class DiscountCodeController extends BaseController {

    @Autowired
    @Qualifier("derbyDao")
    private DerbyDao dao;

    @GetMapping("/")
    //@RequestMapping(value = "/", method = RequestMethod.GET)
    public String query(Model model) {
        DiscountCode po = new DiscountCode();
        model.addAttribute("po", po);
        model.addAttribute("list", dao.queryDiscountCode());
        model.addAttribute("page", "discount_code");
        model.addAttribute("_method", "POST");
        return model.asMap().get("page").toString();
    }

    @GetMapping("/{code}")
    //@RequestMapping(value = "/{code}", method = RequestMethod.GET)
    public String get(@PathVariable("code") String code, Model model) {
        model.addAttribute("po", dao.getDiscountCode(code));
        model.addAttribute("list", dao.queryDiscountCode());
        model.addAttribute("page", "discount_code");
        model.addAttribute("_method", "PUT");

        return model.asMap().get("page").toString();
    }

    @PostMapping("/")
    //@RequestMapping(value = "/", method = RequestMethod.POST)
    public String post(@ModelAttribute DiscountCode dc) {
        dao.saveDiscountCode(dc);
        return "redirect: ./";
    }

    @PutMapping("/")
    //@RequestMapping(value = "/", method = RequestMethod.PUT)
    public String put(@ModelAttribute DiscountCode dc) {
        dao.updateDiscountCode(dc);
        return "redirect: ./";
    }

    @DeleteMapping("/{code}")
    //@RequestMapping(value = "/{code}", method = RequestMethod.DELETE)
    public String delete(@PathVariable("code") String code) {
        dao.deleteDiscountCode(code);
        return "redirect: ./";
    }


}
