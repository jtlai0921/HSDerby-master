package com.web.mvc.controller;

import com.web.mvc.entity.MicroMarket;
import com.web.mvc.repository.spec.DerbyDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/micro_market")
public class MicroMarketController extends BaseController {
    
    @Autowired
    @Qualifier("derbyDao")
    private DerbyDao dao;

    @GetMapping("/")
    //@RequestMapping(value = "/", method = RequestMethod.GET)
    public String query(Model model) {
        MicroMarket po = new MicroMarket();
        model.addAttribute("po", po);
        model.addAttribute("list", dao.queryMicroMarket());
        model.addAttribute("page", "micro_market");
        model.addAttribute("_method", "POST");
        return model.asMap().get("page").toString();
    }

    @GetMapping("/{code}")
    public String get(@PathVariable("code") String code, Model model) {
        model.addAttribute("po", dao.getMicroMarket(code));
        model.addAttribute("list", dao.queryMicroMarket());
        model.addAttribute("page", "micro_market");
        model.addAttribute("_method", "PUT");

        return model.asMap().get("page").toString();
    }

    @PostMapping("/")
    public String post(@ModelAttribute MicroMarket mm) {
        dao.saveMicroMarket(mm);
        return "redirect: ./";
    }

    @PutMapping("/")
    public String put(@ModelAttribute MicroMarket mm) {
        dao.updateMicroMarket(mm);
        return "redirect: ./";
    }

    @DeleteMapping("/{code}")
    public String delete(@PathVariable("code") String code) {
        dao.deleteMicroMarket(code);
        return "redirect: ./";
    }
    
    
}
