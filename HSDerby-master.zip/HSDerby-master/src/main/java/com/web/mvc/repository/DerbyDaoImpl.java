package com.web.mvc.repository;

import com.web.mvc.repository.spec.DerbyDao;
import com.web.mvc.entity.Customer;
import com.web.mvc.entity.DiscountCode;
import com.web.mvc.entity.Manufacturer;
import com.web.mvc.entity.Menu;
import com.web.mvc.entity.MicroMarket;
import com.web.mvc.entity.Product;
import com.web.mvc.entity.ProductCode;
import com.web.mvc.entity.PurchaseOrder;
import java.text.SimpleDateFormat;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository(value = "derbyDao")
public class DerbyDaoImpl implements DerbyDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private RM rm;

    @Override
    public List<Customer> queryCustomer() {
        String sql = "SELECT * FROM CUSTOMER";
        List<Customer> list = jdbcTemplate.query(sql, rm.customerMapper);
        return list;
    }

    @Override
    public Customer getCustomer(Integer id) {
        String sql = "SELECT * FROM CUSTOMER WHERE CUSTOMER_ID = ?";
        Customer customer = jdbcTemplate.queryForObject(sql, new Object[]{id}, rm.customerMapper);
        return customer;
    }

    @Override
    public void saveCustomer(Customer customer) {
        String sql = "INSERT INTO CUSTOMER("
                + "CUSTOMER_ID, DISCOUNT_CODE, ZIP, NAME, "
                + "ADDRESSLINE1, ADDRESSLINE2, CITY, STATE, "
                + "PHONE, FAX, EMAIL, CREDIT_LIMIT) "
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                customer.getCustomerId(),
                customer.getDiscountCode(),
                customer.getZip(),
                customer.getName(),
                customer.getAddressline1(),
                customer.getAddressline2(),
                customer.getCity(),
                customer.getState(),
                customer.getPhone(),
                customer.getFax(),
                customer.getEmail(),
                customer.getCreditLimit());
    }

    @Override
    public void updateCustomer(Customer customer) {
        String sql = "UPDATE CUSTOMER SET "
                + "DISCOUNT_CODE = ?, ZIP = ?, NAME = ?, "
                + "ADDRESSLINE1 = ?, ADDRESSLINE2 = ?, CITY = ?, STATE = ?, "
                + "PHONE = ?, FAX = ?, EMAIL = ?, CREDIT_LIMIT = ? "
                + "WHERE CUSTOMER_ID = ?";
        jdbcTemplate.update(sql,
                customer.getDiscountCode(),
                customer.getZip(),
                customer.getName(),
                customer.getAddressline1(),
                customer.getAddressline2(),
                customer.getCity(),
                customer.getState(),
                customer.getPhone(),
                customer.getFax(),
                customer.getEmail(),
                customer.getCreditLimit(),
                customer.getCustomerId());
    }

    @Override
    public void deleteCustomer(Integer id) {
        String sql = "DELETE FROM CUSTOMER WHERE CUSTOMER_ID = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public List<DiscountCode> queryDiscountCode() {
        List<DiscountCode> list = jdbcTemplate.query("SELECT * FROM DISCOUNT_CODE", rm.discountCodeMapper);
        return list;
    }

    @Override
    public DiscountCode getDiscountCode(String code) {
        String sql = "SELECT * FROM DISCOUNT_CODE WHERE DISCOUNT_CODE = ?";
        DiscountCode dc = jdbcTemplate.queryForObject(sql, new Object[]{code}, rm.discountCodeMapper);
        return dc;
    }

    @Override
    public void saveDiscountCode(DiscountCode dc) {
        String sql = "INSERT INTO DISCOUNT_CODE(DISCOUNT_CODE, RATE) VALUES(?, ?)";
        jdbcTemplate.update(sql, dc.getDiscountCode(), dc.getRate());
    }

    @Override
    public void updateDiscountCode(DiscountCode dc) {
        String sql = "UPDATE DISCOUNT_CODE SET RATE = ? WHERE DISCOUNT_CODE = ?";
        jdbcTemplate.update(sql, dc.getRate(), dc.getDiscountCode());
    }

    @Override
    public void deleteDiscountCode(String code) {
        String sql = "DELETE FROM DISCOUNT_CODE WHERE DISCOUNT_CODE = ?";
        jdbcTemplate.update(sql, code);
    }

    @Override
    public List<MicroMarket> queryMicroMarket() {
        String sql = "SELECT * FROM MICRO_MARKET";
        List<MicroMarket> list = jdbcTemplate.query(sql, rm.microMarketMapper);
        return list;
    }

    @Override
    public MicroMarket getMicroMarket(String code) {
        String sql = "SELECT * FROM MICRO_MARKET WHERE ZIP_CODE = ?";
        MicroMarket dc = jdbcTemplate.queryForObject(sql, new Object[]{code}, rm.microMarketMapper);
        return dc;
    }

    @Override
    public void saveMicroMarket(MicroMarket mm) {
        String sql = "INSERT INTO MICRO_MARKET(ZIP_CODE, RADIUS, AREA_LENGTH, AREA_WIDTH) VALUES(?, ?, ?, ?)";
        jdbcTemplate.update(sql, mm.getZipCode(), mm.getRadius(), mm.getAreaLength(), mm.getAreaWidth());
    }

    @Override
    public void updateMicroMarket(MicroMarket mm) {
        String sql = "UPDATE MICRO_MARKET SET RADIUS = ?, AREA_LENGTH = ?, AREA_WIDTH = ? WHERE ZIP_CODE = ?";
        jdbcTemplate.update(sql, mm.getRadius(), mm.getAreaLength(), mm.getAreaWidth(), mm.getZipCode());
    }

    @Override
    public void deleteMicroMarket(String code) {
        String sql = "DELETE FROM MICRO_MARKET WHERE ZIP_CODE = ?";
        jdbcTemplate.update(sql, code);
    }

    @Override
    public List<Menu> queryMenu() {
        List<Menu> list = jdbcTemplate.query("select * from Menu", rm.menuMapper);
        return list;
    }

    @Override
    public List<ProductCode> queryProductCode() {
        String sql = "SELECT * FROM PRODUCT_CODE";
        List<ProductCode> list = jdbcTemplate.query(sql, rm.productCodeMapper);
        return list;
    }

    @Override
    public ProductCode getProductCode(String code) {
        String sql = "SELECT * FROM PRODUCT_CODE WHERE PROD_CODE = ?";
        ProductCode pc = jdbcTemplate.queryForObject(sql, new Object[]{code}, rm.productCodeMapper);
        return pc;
    }

    @Override
    public void saveProductCode(ProductCode pc) {
        String sql = "INSERT INTO PRODUCT_CODE(PROD_CODE, DISCOUNT_CODE, DESCRIPTION) VALUES(?, ?, ?)";
        jdbcTemplate.update(sql, pc.getProdCode(), pc.getDiscountCode(), pc.getDescription());
    }

    @Override
    public void updateProductCode(ProductCode pc) {
        String sql = "UPDATE PRODUCT_CODE SET DISCOUNT_CODE = ?, DESCRIPTION = ? WHERE PROD_CODE = ?";
        jdbcTemplate.update(sql, pc.getDiscountCode(), pc.getDescription(), pc.getProdCode());
    }

    @Override
    public void deleteProductCode(String code) {
        String sql = "DELETE FROM PRODUCT_CODE WHERE PROD_CODE = ?";
        jdbcTemplate.update(sql, code);
    }

    @Override
    public List<Manufacturer> queryManufacturer() {
        String sql = "SELECT * FROM MANUFACTURER";
        List<Manufacturer> list = jdbcTemplate.query(sql, rm.manufacturerMapper);
        return list;
    }

    @Override
    public Manufacturer getManufacturer(Integer id) {
        String sql = "SELECT * FROM MANUFACTURER WHERE MANUFACTURER_ID = ?";
        Manufacturer mf = jdbcTemplate.queryForObject(sql, new Object[]{id}, rm.manufacturerMapper);
        return mf;
    }

    @Override
    public void saveManufacturer(Manufacturer mf) {
        String sql = "INSERT INTO MANUFACTURER(MANUFACTURER_ID, NAME, ADDRESSLINE1, ADDRESSLINE2,"
                + "CITY, STATE, ZIP, PHONE, FAX, EMAIL, REP) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                mf.getManufacturerId(), mf.getName(), mf.getAddressline1(), mf.getAddressline2(),
                mf.getCity(), mf.getState(), mf.getZip(), mf.getPhone(), mf.getFax(), mf.getEmail(), mf.getRep()
        );
    }

    @Override
    public void updateManufacturer(Manufacturer mf) {
        String sql = "UPDATE MANUFACTURER SET NAME = ?, ADDRESSLINE1 = ?, ADDRESSLINE2 = ?,"
                + "CITY = ?, STATE = ?, ZIP = ?, PHONE = ?, FAX = ?, EMAIL = ?, REP = ? "
                + "WHERE MANUFACTURER_ID = ?";
        jdbcTemplate.update(sql,
                mf.getName(), mf.getAddressline1(), mf.getAddressline2(),
                mf.getCity(), mf.getState(), mf.getZip(), mf.getPhone(), mf.getFax(), mf.getEmail(), mf.getRep(),
                mf.getManufacturerId()
        );
    }

    @Override
    public void deleteManufacturer(Integer id) {
        String sql = "DELETE FROM MANUFACTURER WHERE MANUFACTURER_ID = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public List<Product> queryProduct() {
        String sql = "SELECT * FROM PRODUCT";
        List<Product> list = jdbcTemplate.query(sql, rm.productMapper);
        return list;
    }

    @Override
    public Product getProduct(Integer id) {
        String sql = "SELECT * FROM PRODUCT WHERE PRODUCT_ID = ?";
        Product p = jdbcTemplate.queryForObject(sql, new Object[]{id}, rm.productMapper);
        return p;
    }

    @Override
    public void saveProduct(Product p) {
        String sql = "INSERT INTO PRODUCT"
                + "(PRODUCT_ID, MANUFACTURER_ID, PRODUCT_CODE, PURCHASE_COST, "
                + "QUANTITY_ON_HAND, MARKUP, AVAILABLE, DESCRIPTION) "
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                p.getProductId(), p.getManufacturerId(), p.getProductCode(), p.getPurchaseCost(),
                p.getQuantityOnHand(), p.getMarkup(), p.getAvailable(), p.getDescription()
        );
    }

    @Override
    public void updateProduct(Product p) {
        String sql = "UPDATE PRODUCT SET "
                + "MANUFACTURER_ID = ?, PRODUCT_CODE = ?, PURCHASE_COST = ?, QUANTITY_ON_HAND = ?, "
                + "MARKUP = ?, AVAILABLE = ?, DESCRIPTION = ? "
                + "WHERE PRODUCT_ID = ?";
        jdbcTemplate.update(sql,
                p.getManufacturerId(), p.getProductCode(), p.getPurchaseCost(), p.getQuantityOnHand(),
                p.getMarkup(), p.getAvailable(), p.getDescription(),
                p.getProductId()
        );
    }

    @Override
    public void deleteProduct(Integer id) {
        String sql = "DELETE FROM PRODUCT WHERE PRODUCT_ID = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public List<PurchaseOrder> queryPurchaseOrder() {
        String sql = "SELECT * FROM PURCHASE_ORDER";
        List<PurchaseOrder> list = jdbcTemplate.query(sql, rm.purchaseOrderMapper);
        return list;
    }

    @Override
    public PurchaseOrder getPurchaseOrder(Integer num) {
        String sql = "SELECT * FROM PURCHASE_ORDER WHERE ORDER_NUM = ?";
        PurchaseOrder p = jdbcTemplate.queryForObject(sql, new Object[]{num}, rm.purchaseOrderMapper);
        return p;
    }

    @Override
    public void savePurchaseOrder(PurchaseOrder purchaseOrder) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String sql = "INSERT INTO PURCHASE_ORDER("
                + "ORDER_NUM, CUSTOMER_ID, PRODUCT_ID, QUANTITY, "
                + "SHIPPING_COST, SALES_DATE, SHIPPING_DATE, FREIGHT_COMPANY) "
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                purchaseOrder.getOrderNum(),
                purchaseOrder.getCustomerId(),
                purchaseOrder.getProductId(),
                purchaseOrder.getQuantity(),
                purchaseOrder.getShippingCost(),
                sdf.format(purchaseOrder.getSalesDate()),
                sdf.format(purchaseOrder.getShippingDate()),
                purchaseOrder.getFreightCompany());
    }

    @Override
    public void updatePurchaseOrder(PurchaseOrder purchaseOrder) {
        
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String sql = "UPDATE PURCHASE_ORDER SET "
                + "CUSTOMER_ID=?, PRODUCT_ID=?, QUANTITY=?, "
                + "SHIPPING_COST=?, SALES_DATE=?, SHIPPING_DATE=?, FREIGHT_COMPANY=? "
                + "WHERE ORDER_NUM=?";
        jdbcTemplate.update(sql,
                purchaseOrder.getCustomerId(),
                purchaseOrder.getProductId(),
                purchaseOrder.getQuantity(),
                purchaseOrder.getShippingCost(),
                sdf.format(purchaseOrder.getSalesDate()),
                sdf.format(purchaseOrder.getShippingDate()),
                purchaseOrder.getFreightCompany(),
                purchaseOrder.getOrderNum());
    }

    @Override
    public void deletePurchaseOrder(Integer num) {
        String sql = "DELETE FROM PURCHASE_ORDER WHERE ORDER_NUM = ?";
        jdbcTemplate.update(sql, num);
    }
}
