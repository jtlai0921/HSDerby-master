package com.web.mvc.controller;

import com.web.mvc.entity.PurchaseOrder;
import com.web.mvc.repository.spec.DerbyDao;
import com.web.mvc.validator.PurchaseOrderValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/purchase_order")
public class PurchaseOrderController extends BaseController {

    @Autowired
    @Qualifier("derbyDao")
    private DerbyDao dao;
    
    @Autowired
    private PurchaseOrderValidator validator;
    
    @RequestMapping("/")
    public String input(Model model) {
        PurchaseOrder purchaseOrder = new PurchaseOrder();
        model.addAttribute("purchaseOrder", purchaseOrder);
        model.addAttribute("list", dao.queryPurchaseOrder());
        model.addAttribute("list_c", dao.queryCustomer());
        model.addAttribute("list_p", dao.queryProduct());
        model.addAttribute("page", "purchase_order");
        model.addAttribute("page_action", "save");
        model.addAttribute("_method", "post");
        return model.asMap().get("page").toString();
    }
    
    @RequestMapping("/{num}")
    public String get(@PathVariable("num") Integer num, Model model) {
        model.addAttribute("purchaseOrder", dao.getPurchaseOrder(num));
        model.addAttribute("list", dao.queryPurchaseOrder());
        model.addAttribute("list_c", dao.queryCustomer());
        model.addAttribute("list_p", dao.queryProduct());
        model.addAttribute("page", "purchase_order");
        model.addAttribute("page_action", "update");
        model.addAttribute("_method", "post");

        return model.asMap().get("page").toString();
    }

    @PostMapping("/save")
    public String save(@ModelAttribute PurchaseOrder purchaseOrder, BindingResult result, Model model) {
        this.validator.validate(purchaseOrder, result); // 驗證
        if(result.hasErrors()) {
            model.addAttribute("list", dao.queryPurchaseOrder());
            model.addAttribute("list_c", dao.queryCustomer());
            model.addAttribute("list_p", dao.queryProduct());
            model.addAttribute("page", "purchase_order");
            model.addAttribute("page_action", "save");
            model.addAttribute("_method", "post");
            return model.asMap().get("page").toString();
        }
        dao.savePurchaseOrder(purchaseOrder);
        return "redirect: ./";
    }

    @PostMapping("/update")
    public String update(@ModelAttribute PurchaseOrder purchaseOrder, BindingResult result, Model model) {
        this.validator.validate(purchaseOrder, result); // 驗證
        if(result.hasErrors()) {
            model.addAttribute("list", dao.queryPurchaseOrder());
            model.addAttribute("list_c", dao.queryCustomer());
            model.addAttribute("list_p", dao.queryProduct());
            model.addAttribute("page", "purchase_order");
            model.addAttribute("page_action", "update");
            model.addAttribute("_method", "post");
            return model.asMap().get("page").toString();
        }
        dao.updatePurchaseOrder(purchaseOrder);
        return "redirect: ./";
    }

    @DeleteMapping("/{num}")
    public String delete(@PathVariable("num") Integer num) {
        dao.deletePurchaseOrder(num);
        return "redirect: ./";
    }


}
